﻿using System.Runtime.CompilerServices;

// Grant the test project access to internal members of this project
[assembly: InternalsVisibleTo("BlazorLabStarterCodeTests")]

namespace Blazor_Lab_Starter_Code
{
    // Assembly-level attributes like InternalsVisibleTo are declared here.
    internal class AssemblyInfo
    {
    }
}