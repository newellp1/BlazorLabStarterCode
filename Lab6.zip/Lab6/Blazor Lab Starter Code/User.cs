﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blazor_Lab_Starter_Code {
    class User {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
